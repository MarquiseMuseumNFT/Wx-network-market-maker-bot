#!/bin/bash
set -a
source .env
set +a

python3 bot.py
